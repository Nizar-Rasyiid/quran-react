import React from 'react';
const Layout = ({ children }) => { //Tambah props children
    return (
        <React.Fragment>
            <div className="">
                {/* Navbar */}
                <div className="">Navbar</div>

                <div className="flex">
                    {/* sidebar */}
                    <div className="w-1/5 border   h-screen">Sidebar</div>
                    {/* content */}
                    <div className="w-4/5 border  h-screen text-black p-1">{children}</div>
                </div>
            </div>

            </React.Fragment>
        );
    }

    export default Layout;