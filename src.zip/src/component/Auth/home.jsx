import React from 'react';
const Home = React.memo(() => {
    return (
        <div>
           ini adalah Home
        </div>
    )
})

export default Home;