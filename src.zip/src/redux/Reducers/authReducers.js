const defaultState = {
    name:  "nama saya",
    auth : false,
    message:  ""
}

const authReducers = (state = defaultState, action) => {
    switch (action.type) {
        case "LOGIN":
            return{
                ...state,
                name : action.name,
                auth : action.auth,
                message : "Anda Telah Login"
            }    

            break;
        case "LOGOUT":
            return {
                ...state,
                name: action.name,
                auth: action.auth,
                message: "Anda Telah Logout"
            }

            break;
    
        default:
            return{
                ...state
            }
            break;
    }
}
export default authReducers