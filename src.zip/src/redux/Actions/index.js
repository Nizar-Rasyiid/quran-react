export const counterIncrement = () => {
    return {
        type : "INCREMENT"
    }
}
export const counterDecrement = () => {
    return {
        type: "Decrement"
    }
}

export const login = () => {
    return{
        type : "LOGIN",
        auth : true,
        name : "admin"
    }
}

export const logout = () => {
    return {
        type : "LOGOUT",
        auth : false,
        name:""
    }
}