import {createStore, combineReducers} from 'redux'
// createStore untuk membuat store 
// combineReducers untuk menggabungkan reducer
import authReducers from '/belajarReact/belajarreact/src/redux/Reducers/authReducers'
import counterReducers from '../Reducers/counterReducers'

let rootReducers = combineReducers ({
    auth : authReducers,
    counter : counterReducers
       
})

let store = createStore(rootReducers, window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__())

export default store