import React from 'react'
// membuat kelas component

class Home3 extends React.Component{
    render(){
        return(
            <React.Fragment>
                ini adalah class component
            </React.Fragment>
        )
    }
}
export default Home3;