import React from 'react'

// membuat component

function Home () {
    return (
        <div className="text-red">
            ini adalah functional component
        </div>
    )
}

export default Home;
