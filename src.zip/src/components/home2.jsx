import React from 'react'


// Membuat component dgn arrow function

const Home2 = () => {
    return(
        <div className="">
            this is functional component with arrow function
        </div>
    )
}
export default Home2;